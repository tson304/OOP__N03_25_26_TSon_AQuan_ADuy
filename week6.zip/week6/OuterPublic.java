package week6;

public class OuterPublic {
    public class InnerPublic{
        public void print(){
        System.out.println("Day la public inner class");
}
}
}
