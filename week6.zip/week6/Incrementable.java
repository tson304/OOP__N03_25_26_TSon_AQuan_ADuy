package week6;

public interface Incrementable {
    void increment();}
